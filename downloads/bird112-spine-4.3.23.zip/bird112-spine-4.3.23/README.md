# 112 双翼飞行生物 · Spine PRO 4.3.23

根据上传的 `112.json` 与 11 张透明 PNG 制作，保留原始图片和图层顺序。新增 25 根骨骼和 11 个网格，提供五个动作：`stand`、`dead`、`hit`、`move`、`attack`。双翼、长尾与长颚使用连续加权网格，翼尖、尾尖、背鳍和颚部有延迟跟随；不补绘未知的遮挡部位。

## 导入本地 Spine

1. 完整解压 ZIP，保持 `bird112-4.3.json` 与 `images/` 的相对目录。
2. 在 **Spine PRO 4.3.23** 中选择“导入数据”，导入根目录 **`bird112-4.3.json`**，缩放填写 **1**。图片路径为 `./images/`。
3. 保存为自己的 `.spine` 工程。本包提供可编辑 JSON，不伪造二进制 `.spine` 文件。
4. 动画模式中，`stand`、`move`、`attack` 打开循环；`hit` 播放一次，`dead` 播放一次并保持最后一帧。

需要 Professional 的加权网格功能。原始的 `bqiqi01` 等附件名称保持不变，避免贴图引用失效。

| 动作 | 时长 | 内容 |
| --- | --- | --- |
| `stand` | 2.4 秒 | 空中待机，慢振翅、呼吸、身体轻浮动，尾巴与背鳍延迟摆动 |
| `move` | 0.8 秒 | 原地飞行，大幅快速振翅、身体稍前倾，翼尖弹性跟随 |
| `attack` | 0.8 秒 | 持续原地俯冲，头低尾高、双翼收拢，小幅压翼与回弹 |
| `hit` | 0.5 秒 | 身体后震、张翼卸力、颚部摆动后复位 |
| `dead` | 1.6 秒 | 失衡下落、收翼落地、颚部收拢与短促回弹，末尾静止 |

## 俯冲循环与游戏接入

素材朝左。`attack` 中躯干保持约 **32–40°** 的向下俯冲倾角，双翼展幅收缩，头部低于身体、尾部抬高。**循环首尾都是俯冲姿态**，不会每圈恢复水平、重新蓄力，适合持续俯冲状态。循环内部用压翼、回弹和尾部延迟表现气流与速度感。

从 `stand` 或 `move` 切换到 `attack`，推荐设置约 **0.12–0.18 秒混合**，自然进入俯冲；退出时同样短混合。不要在每个循环结束时先切回待机。

`stand`、`move`、`attack` 的 **根骨骼位置始终为 0,0**。这是原地表演，身体轻浮动在 `hover` 子骨骼上，不会让角色在世界中向前或向下飞走。飞行速度、俯冲路径、追踪、碰撞和伤害由游戏控制。`dive_contact` 是可供参考的接触点骨骼，当前没有在每个循环里自动发送伤害事件。

`hit` 在 0.1 秒有 `impact` 事件，`dead` 在 1.4 秒有 `death_end` 事件。死亡动作包含高度下降，落地后保持，不能作为飞行循环使用。

## 预览与素材

- `preview.html`：五动作普通尺寸和手机尺寸 GIF、关键姿势与绑骨图。
- `previews/attack.gif`、`mobile-attack.gif`：持续原地俯冲循环。
- `previews/animation-contact.png`：五动作关键帧。
- `previews/rig-setup.png`：骨骼和网格设置示意。
- `images/*.png`：11 张原始透明 PNG，图片字节不变。
- `source/image-sha256.json`：原图 SHA256 清单。
- `source/112.json`：原始上传的 Photoshop JSON。
- `source/photoshop.json`：规范化图片路径后的源数据，坐标与图层顺序保留。
- `rig-config.json`：关节、绑定和尾部曲线设置。
- `runtime-validation.json`：官方运行库逐帧检查记录。

GIF 为独立软件渲染，**不是 Spine 桌面截图**；骨骼矩阵和网格采样点已与官方运行库交叉比对。普通飞行动作的手机尺寸预览中，角色高度约 128px，俯冲和死亡因姿态改变会有不同的屏幕轮廓。

可直接用普通浏览器打开 `preview.html`。若本机限制文件资源，可在此目录执行 `python -m http.server 8000`，打开 `http://127.0.0.1:8000/preview.html`。云端实际浏览器检查使用临时 HTTP 服务，不代表已验证本机 `file://` 或 Codex 内嵌预览。

本包是编辑器导入数据与原图，尚不是已打包的游戏 atlas。请在本机导入、保存工程，再按目标游戏运行库导出 JSON/二进制和图集。

## 验证与复现

从 LostFleet-Tools 仓库根目录运行：

```sh
python tools/build_bird112_spine.py
SPINE_CORE_MODULE=/absolute/path/to/@esotericsoftware/spine-core/dist/index.js node tests/validate_bird11243.mjs
python -m unittest discover -s tests -v
```

官方 `@esotericsoftware/spine-core 4.3.13` 以 60 Hz 检查五动作 **371 个姿势**，所有网格顶点检查有限值。Python 独立实现交叉比对骨骼矩阵、采样网格顶点、显示隐藏和图层顺序。自动化另外检查原图哈希、原始组装、正权重归一化、循环首尾、根节点零位移、俯冲持续向下、收翼幅度、振翅幅度、翼尖/尾尖延迟、关键姿势的连接性和死亡接地。

**目标为 Spine PRO 4.3.23；当前环境无法启动该桌面编辑器，尚未实测桌面导入。** 已完成官方同系列 4.3 运行库验证，请在本机导入确认后保存工程。
