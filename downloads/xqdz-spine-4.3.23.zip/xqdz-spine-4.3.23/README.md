# XQDZ · Spine 4.3 动画初稿

使用你提供的 PS JSON 和 9 张透明 PNG，建立 13 根骨骼，生成待机、开枪、受击、死亡和原地移动动画。目标编辑器版本：**Spine 4.3.23**。

**验证范围：** 已用官方 `@esotericsoftware/spine-core@4.3.13` 运行库实际加载并应用五个动画，共 167 个姿态。已将预览的全部骨骼变换与官方运行库采样逐一比较。这里没有 Spine 桌面软件，**未实机验证 4.3.23 编辑器导入，也未生成原生 `.spine` 工程**。这是可继续编辑的第一版，不是最终游戏动作或物理模拟。

预览页面的 GIF/PNG 已通过临时 HTTP 服务在 Chromium 中检查。当前云浏览器的管理策略禁止 `file://`，所以未验证该浏览器直接打开本地 HTML；如果你的浏览器也禁止本地文件，可跳过 GIF 预览直接导入 Spine，或在素材文件夹运行 `py -3.12 -m http.server 8001 --bind 127.0.0.1`，然后访问 `http://127.0.0.1:8001/preview.html`。

## 在本地 Spine 中使用

如果下载的是独立的 `xqdz-spine-4.3.23.zip`，解压后直接进入其中包含 JSON、`images` 和 `preview.html` 的文件夹，从下方第 2 步开始；独立包无需安装 Python，也无需启动网页工具。修改配置后重建或运行测试则需要完整仓库中的脚本。

1. 下载 `codex/xqdz-spine-animations` 分支的完整 ZIP，并解压。不要下载默认 `main` 分支。
2. 打开解压目录中的 `examples/xqdz-spine`。先双击 `preview.html`，在普通浏览器里查看五个 GIF；无需启动 Python 服务。
3. 打开本地 Spine 4.3.23，选择菜单 **导入数据 / Import Data**，选取 **`xqdz-4.3.json`**。这是骨骼 JSON，不要当作 `.spine` 工程直接“打开”。导入比例使用 1。
4. 如果图片显示为缺失，请在骨骼树选择“图片 / Images”节点，将图片目录指向本文件夹中的 **`images`**。不要使用原来的 E 盘绝对路径。
5. 在 Setup（设置）模式检查拼装，再切到 Animate（动画）模式，依次选择 `idle`、`attack`、`hit`、`death`、`move`。
6. 待机和移动开启循环；攻击按需要播放，受击和死亡通常不循环。`death` 最后保持倒地姿势。
7. 将项目保存为本目录下的 `xqdz.spine`，保持旁边 `images` 文件夹位置不变。完成手工微调后，再从 Spine 导出游戏需要的 JSON/二进制与图集。

本目录没有 `.atlas`，因为 Spine 编辑器可直接读取分离 PNG。游戏运行时的最终图集应由你的本地 Spine 导出。

## 动作清单

| 名称 | 时长 | 设计 |
| --- | --- | --- |
| `idle` | 2.0 秒 | 轻微呼吸、头部平衡、两根独立触须摆动 |
| `attack` | 0.8 秒 | 面向左侧开枪，双臂和枪整体后坐，枪口三帧火花 |
| `hit` | 0.4 秒 | 上身后仰、头部和触须震动，末帧恢复 |
| `death` | 1.4 秒 | 向右侧倒地、轻微回弹，最后保持地面接触 |
| `move` | 0.8 秒 | 原地整腿交替摆动、身体起伏，位移交给游戏代码 |

所有关键帧按 30 FPS 采样，旋转使用 Spine 4.3 的 `value` 字段，旧 PS 皮肤对象转换成现代 `skins` 数组。待机和移动首尾变换一致。显示方向保留原图朝左。

`attack` 在第 8 帧（约 0.266667 秒）触发 `shoot` 事件，三张火花从第 8–10 帧依次显示，第 11 帧隐藏。其他动作第 0 帧明确隐藏火花。`shoot` 事件只是时间标记，需要游戏代码接入子弹、伤害、声音；此包没有声音、弹道或子弹逻辑。另含 `footstep`、`impact`、`death_end` 事件。

## 骨骼与图片

```text
root
└── pelvis
    ├── body
    │   ├── head
    │   │   ├── antenna_01  ← cx01
    │   │   └── antenna_02  ← cx02
    │   └── aim
    │       ├── right_arm
    │       ├── left_arm
    │       └── weapon
    │           └── muzzle
    ├── right_leg
    └── left_leg
```

保留全部原始图片文件名和原图层遮挡顺序。坐标统一移至脚底附近原点，附件经父骨骼逆变换，保持与 PS 原始拼装相同的相对位置。原始 PNG 的 SHA-256 在 `source/image-sha256.json` 中，未修改图像内容。`source/photoshop.json` 保留原始 PS 数据结构，只把机器特定的 E 盘路径换成相对图片路径。

`muzzle` 是枪口标记，绑定在 `weapon` 下。火花位于 `images/fx/`，为本次程序绘制的几何特效初稿，**不是从原图恢复的素材**，可在 Spine 中替换。骨骼与关节位置是根据分层图片估计的初始值，建议在本地检查肩部、脖子、髋部、触须根部和枪口。

## 当前限制和建议微调

- 双臂和双腿都是整张图片，没有拆肘、膝或独立脚掌。当前采用刚性图片旋转与位移，没有网格权重或 IK，走路可能有滑步，不能当作自然弯腿行走。
- 原始素材有重叠区域；动作幅度较大时仍可能出现肩髋接缝或穿插。未补绘任何被遮挡的肢体。
- 枪与双手通过 `aim` 同步运动，没有额外手部 IK。请检查最大后坐时的握持位置。
- 死亡是预设的整身侧倒，地面高度按当前图像预览校正，不是物理模拟。更细腻的倒地需要拆腿、网格或人工调整。
- GIF 使用项目自带的 Pillow 仿射渲染器，棋盘格和地面线只存在于预览中。变换已与官方运行库比对，但 GIF 不等于 Spine 桌面视窗截图；火花的 additive 混合在桌面上可能更亮。

## 自行调整与重建（可选）

`rig-config.json` 保存骨骼的父级、原始 PS 世界坐标、朝向和枪口位置。位置坐标为 PS 导出中的 X 向右、Y 向上（当前原图的 Y 为负）。原点为 `[270, -463]`。修改配置后，可在仓库根目录执行：

```bat
.venv\Scripts\python.exe tools\build_xqdz_spine.py
```

需要先安装仓库的 `requirements.txt`。脚本覆盖本目录的生成 JSON、火花和预览，**不会修改原始 9 张 PNG**。在 Spine 内手动改好的工程应另存，避免重新生成后丢失手工修改。动作参数在 `tools/build_xqdz_spine.py` 的 `make_animations()` 中。

Python 验证：

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

运行库验证为可选开发检查，要求 Node.js 和官方 Spine 运行库，不是导入本地 Spine 的前置条件。不要为了看动画安装这些开发工具：

```bat
npm install --no-save --package-lock=false @esotericsoftware/spine-core@4.3.13
node tests/validate_spine43.mjs
```

`runtime-validation.json` 是当前 JSON 的官方运行库采样报告，包含输入文件 SHA-256；修改生成数据后需要重新执行运行库检查才能更新报告。Python 测试会拒绝过期报告。
